﻿using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;
using Windows.Win32.Foundation;
using Windows.Win32.Storage.FileSystem;
using PInvoke = Windows.Win32.PInvoke;

namespace LibreHardwareMonitor.PawnIo;

public class PawnIo
{
    private const uint DEVICE_TYPE = 41394u << 16;
    private const int FN_NAME_LENGTH = 32;
    private const uint IOCTL_PIO_EXECUTE_FN = 0x841 << 2;
    private const uint IOCTL_PIO_LOAD_BINARY = 0x821 << 2;

    private static readonly System.Collections.Generic.Dictionary<string,string> ModuleHashes = new()
    {
        ["LibreHardwareMonitor.Resources.PawnIo.AMDFamily0F.bin"] = "1788550C02100AD6BBC91604399ED6E055058EA0F6C0C828C02D9B01A09AD27F",
        ["LibreHardwareMonitor.Resources.PawnIo.AMDFamily10.bin"] = "79BE1396621AA44EB149C5DC6D1BAB4519B9CFA49A32AF5E022CB9F9CA887658",
        ["LibreHardwareMonitor.Resources.PawnIo.AMDFamily17.bin"] = "099DC01D6DB97EA997FEC4A461E191CC64B9D7CE47C9D2153C451C56C2ADCF50",
        ["LibreHardwareMonitor.Resources.PawnIo.IntelMSR.bin"] = "ED41A0D0DE082F4668A9CACCB9681EBBAD97A8ED3452C41918DDA1EB454B77A9",
        ["LibreHardwareMonitor.Resources.PawnIo.IsaBridgeEC.bin"] = "7218C633384BD019CCE09E8DF91F74996F980765AC44DDE0F22B0B5318C20F03",
        ["LibreHardwareMonitor.Resources.PawnIo.LpcACPIEC.bin"] = "C38FD116E7AFF4D1FDB0A494E296BE0A6708E5A22FC72F14587442FB7F8F7906",
        ["LibreHardwareMonitor.Resources.PawnIo.LpcCrOSEC.bin"] = "277ED6CE6B5F647D5DAE9B06C83ED39E904974B06F95598D49F4737237974776",
        ["LibreHardwareMonitor.Resources.PawnIo.LpcIO.bin"] = "3DCF8B2BC80FF642D97C4608511A818642B5BF315FF53DF3DF393D043E71D101",
        ["LibreHardwareMonitor.Resources.PawnIo.RyzenSMU.bin"] = "0CF0FE1296C5C38F4BEE0F96352B35F14D32AB97CB58FD17600646D98507D8AA",
        ["LibreHardwareMonitor.Resources.PawnIo.SmbusI801.bin"] = "76B082A144027244FE7BBF3CA0E987E7DFA279AA87E0CCC2A6A918E10E2038E1",
        ["LibreHardwareMonitor.Resources.PawnIo.SmbusNCT6793.bin"] = "385BD1B229FAA44AEFE2EB1F938AC629F6D897F1A4931DAB5341B18B3BD432C1",
        ["LibreHardwareMonitor.Resources.PawnIo.SmbusPIIX4.bin"] = "3F8B44C93EB030D59FB68C6FDC6857C61313EAB2B6AA0ED64595396D71BF3EA3",
    };
    public static void VerifyModule(string name, byte[] data)
    {
        using var hash = System.Security.Cryptography.SHA256.Create();
        string actual = BitConverter.ToString(hash.ComputeHash(data)).Replace("-", "");
        if (!ModuleHashes.TryGetValue(name, out var expected) || actual != expected)
            throw new InvalidDataException("Unverified PawnIO module; load refused: " + name);
    }
    private readonly SafeFileHandle _handle;
    private readonly int _loadError;
    // Set by the host only after explicit session opt-in. Never installs/starts a driver.
    public static bool AccessAllowed { get; set; }
    public static bool CleanupUncertain { get; set; }
    public static string AccessDenialReason { get; set; } = "Explicit extended hardware mode required";
    private static readonly System.Collections.Generic.List<string> _diagnostics = new();
    public static string[] AccessDiagnostics { get { lock (_diagnostics) return _diagnostics.ToArray(); } }
    private static PawnIo Failed(string resource, int error, string reason, bool policy = false)
    {
        lock (_diagnostics) if (_diagnostics.Count < 32) _diagnostics.Add(resource + ": " + reason + (policy ? " (host policy denial)" : " (Win32=" + error + ")"));
        return new PawnIo(null, error);
    }
    public static void ValidateTransfer(uint bytes, int capacity)
    {
        if (capacity < 0 || capacity > 1024 * 1024 || bytes != capacity || bytes % sizeof(long) != 0)
            throw new System.IO.InvalidDataException("Malformed PawnIO response length");
    }
    public static int TransferBytes(int count)
    {
        if (count < 0 || count > 131072) throw new ArgumentOutOfRangeException(nameof(count));
        return checked(count * sizeof(long));
    }

    static PawnIo()
    {
        using RegistryKey subKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\PawnIO");

        if (Version.TryParse(subKey?.GetValue("DisplayVersion") as string, out Version version))
        {
            Version = version;
        }
        else
        {
            using RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);

            using RegistryKey subKeyWow64 = registryKey.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\PawnIO");

            if (Version.TryParse(subKeyWow64?.GetValue("DisplayVersion") as string, out version))
            {
                Version = version;
            }
        }
    }

    private PawnIo(SafeFileHandle handle, int error = 0) { _handle = handle; _loadError = error; }

    /// <summary>
    /// Gets a value indicating whether PawnIO is installed on the system.
    /// </summary>
    public static bool IsInstalled => Version is not null;

    /// <summary>
    /// Retrieves the version information for the installed PawnIO.
    /// </summary>
    public static Version Version { get; }

    /// <summary>
    /// Gets a value indicating whether the underlying handle is currently valid and open.
    /// </summary>
    public bool IsLoaded => _handle is
    {
        IsInvalid: false,
        IsClosed: false
    };

    internal static unsafe PawnIo LoadModuleFromResource(Assembly assembly, string resourceName)
    {
        if (!AccessAllowed) return Failed(resourceName, 5, AccessDenialReason, true);
        if (Version == null || Version < new Version(2, 2, 0))
            return Failed(resourceName, 50, "PawnIO >= 2.2.0 is required");
        using Stream stream = assembly.GetManifestResourceStream(resourceName);
        if (stream == null) throw new InvalidDataException("Missing PawnIO module: " + resourceName);
        using MemoryStream memory = new();
        stream.CopyTo(memory);
        byte[] bin = memory.ToArray();
        VerifyModule(resourceName, bin);
        SafeFileHandle handle = PInvoke.CreateFile(@"\\?\GLOBALROOT\Device\PawnIO",
                                                   (uint)FileAccess.ReadWrite,
                                                   FILE_SHARE_MODE.FILE_SHARE_READ | FILE_SHARE_MODE.FILE_SHARE_WRITE,
                                                   null,
                                                   FILE_CREATION_DISPOSITION.OPEN_EXISTING,
                                                   FILE_FLAGS_AND_ATTRIBUTES.FILE_ATTRIBUTE_NORMAL,
                                                   null);

        if (handle.IsInvalid)
        {
            int error = Marshal.GetLastWin32Error();
            handle.Dispose();
            return Failed(resourceName, error, "Opening existing PawnIO device failed");
        }

        fixed (byte* pIn = bin)
        {
            if (SafeIoctl(handle, (uint)ControlCode.LoadBinary, pIn, (uint)bin.Length, null, 0u, null, null))
                return new PawnIo(handle);
        }

        int loadError = Marshal.GetLastWin32Error();
        handle.Dispose();
        return Failed(resourceName, loadError, "Signed module load failed");
    }

    private static unsafe bool SafeIoctl(SafeFileHandle handle, uint code, void* input, uint inputSize, void* output, uint outputSize, uint* read, void* unused)
    {
        bool pinned = false;
        try {
            handle.DangerousAddRef(ref pinned);
            return PInvoke.DeviceIoControl((HANDLE)handle.DangerousGetHandle(), code, input, inputSize, output, outputSize, read, null);
        } finally { if (pinned) handle.DangerousRelease(); }
    }

    public void Close() { lock (this) { if (IsLoaded) _handle.Close(); } }

    public unsafe long[] Execute(string name, long[] input, int outLength)
    {
        lock (this) {

        if (IsLoaded)
        {
            byte[] output = new byte[TransferBytes(outLength)];
            byte[] totalInput = new byte[checked(TransferBytes(input.Length) + FN_NAME_LENGTH)];
            Buffer.BlockCopy(Encoding.ASCII.GetBytes(name), 0, totalInput, 0, Math.Min(FN_NAME_LENGTH - 1, name.Length));
            Buffer.BlockCopy(input, 0, totalInput, FN_NAME_LENGTH, input.Length * sizeof(long));

            uint read = 0;

            fixed (byte* pIn = totalInput, pOut = output)
            {
                if (SafeIoctl(_handle, (uint)ControlCode.Execute, pIn, (uint)totalInput.Length, pOut, (uint)output.Length, &read, null))
                {
                    ValidateTransfer(read, output.Length);
                    long[] outp = new long[read / sizeof(long)];
                    Buffer.BlockCopy(output, 0, outp, 0, (int)read);
                    return outp;
                }
            }
        }

        throw new System.ComponentModel.Win32Exception(IsLoaded ? Marshal.GetLastWin32Error() : _loadError, "PawnIO read failed or device inaccessible");
    
        }
    }

    public unsafe int ExecuteHr(string name, long[] inBuffer, uint inSize, long[] outBuffer, uint outSize, out uint returnSize)
    {
        if (inBuffer.Length < inSize)
            throw new ArgumentOutOfRangeException(nameof(inSize));

        if (outBuffer.Length < outSize)
            throw new ArgumentOutOfRangeException(nameof(outSize));

        if (!IsLoaded)
        {
            returnSize = 0;
            return PInvoke.HRESULT_FROM_WIN32((WIN32_ERROR)(_loadError == 0 ? 5 : _loadError));
        }

        uint read = 0;

        byte[] output = new byte[TransferBytes(checked((int)outSize))];
        byte[] totalInput = new byte[checked(TransferBytes(checked((int)inSize)) + FN_NAME_LENGTH)];
        Buffer.BlockCopy(Encoding.ASCII.GetBytes(name), 0, totalInput, 0, Math.Min(FN_NAME_LENGTH - 1, name.Length));
        Buffer.BlockCopy(inBuffer, 0, totalInput, FN_NAME_LENGTH, TransferBytes(checked((int)inSize)));

        fixed (byte* pIn = totalInput, pOut = output)
        {
            if (SafeIoctl(_handle, (uint)ControlCode.Execute, pIn, (uint)totalInput.Length, pOut, (uint)output.Length, &read, null))
            {
                if (read > output.Length || read % sizeof(long) != 0) { returnSize = 0; return unchecked((int)0x8007000D); }
                Buffer.BlockCopy(output, 0, outBuffer, 0, checked((int)read));
                returnSize = read / sizeof(long);
                return 0;
            }
        }

        returnSize = 0;
        return PInvoke.HRESULT_FROM_WIN32((WIN32_ERROR)Marshal.GetLastWin32Error());
    }

    private enum ControlCode : uint
    {
        LoadBinary = DEVICE_TYPE | IOCTL_PIO_LOAD_BINARY,
        Execute = DEVICE_TYPE | IOCTL_PIO_EXECUTE_FN
    }
}
