// SPDX-License-Identifier: MPL-2.0
using System;
namespace LibreHardwareMonitor.Hardware;
public static class ExpcTransaction
{
    public static T Read<T>(Func<T> read, Action release)
    {
        try { return read(); }
        finally { Cleanup(release); }
    }
    public static void Cleanup(Action release)
    {
        try { release(); }
        catch { LibreHardwareMonitor.PawnIo.PawnIo.CleanupUncertain = true; throw; }
    }
}
