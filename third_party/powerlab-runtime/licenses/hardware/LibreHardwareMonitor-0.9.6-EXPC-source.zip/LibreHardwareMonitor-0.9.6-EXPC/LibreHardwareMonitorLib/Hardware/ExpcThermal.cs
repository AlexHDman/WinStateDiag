using System;
using System.Linq;
namespace LibreHardwareMonitor.Hardware;
public static class ExpcThermal
{
 public static float? Average(float?[] values) => values.Length == 0 || values.Any(v => !v.HasValue || float.IsNaN(v.Value) || float.IsInfinity(v.Value)) ? null : values.Average(v => v.Value);
 public static bool NativeTelemetryOwned { get; set; }
}
